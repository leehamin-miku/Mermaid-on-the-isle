using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LivingEntity : MonoBehaviour, IDamageable
{
    public event Action OnDeath;


    protected float health;
    public float initialHealth = 10;
    public  float MaxHealth{get;protected set;}
    protected bool isDead = false;
    public bool IsDead{
        get{
            return isDead;
        }}

    public void TakeHit(float damage, RaycastHit hit = new RaycastHit())
    {
        if(isDead) 
            return;
        

        health -= damage;
        if(health < 0){
            Die();
        }
    }

    public void Heal(float amount){
        if(isDead)
            return;
        health+=amount;
    }
    private void Die(){
        isDead = true;
        health = 0;


        if(OnDeath != null){
            OnDeath();
        }
        GameObject.Destroy(gameObject);
    }





    protected virtual void Start()
    {
        health = initialHealth;
        MaxHealth = initialHealth;
    }

//음....
    protected virtual void OnTriggerEnter(Collider other) {
        ICollectable collecectable = other.GetComponent<ICollectable>();

        if(collecectable != null){
            collecectable.OnPickUp(this);
        }
    }
}
