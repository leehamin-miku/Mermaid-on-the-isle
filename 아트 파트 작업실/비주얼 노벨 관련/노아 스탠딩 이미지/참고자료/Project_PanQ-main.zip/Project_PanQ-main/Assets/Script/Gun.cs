using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Analytics;

public class Gun : MonoBehaviour
{
    [SerializeField]
    float damage = 10f;
    [SerializeField][Range(1f, 2000f)]
    float msBetweenShot = 100f;
    [SerializeField][Range(1, 100)]
    int pellets = 1;
    [SerializeField][Range(0, 180)]
    float spreadAngles = 15f;
    [SerializeField]
    float projVelocity = 10f;
    [SerializeField]
    float lifeTime = 2f;
    [SerializeField]
    Transform muzzle;
    [SerializeField]
    Projectile projectilePrefab;

    float randomizeVelocityCoef = 0.3f; // 발사체 속도가 이 수치만큼 무작위로 바뀜. ex) 0.3이면 속도가 0.7~1.3배 곱해짐. 몰루의 안정치 비슷한 느낌?
    System.Random prng = new System.Random();
    float nextFireTime = 0;


    public void Fire(){

        if(nextFireTime >= Time.time) 
            return;

        nextFireTime = Time.time + msBetweenShot / 1000;
        
        for(int i=0;i<pellets;i++){      
            Quaternion randomRotation = muzzle.rotation;
            randomRotation *= Quaternion.Euler(Random.Range(-spreadAngles/2,spreadAngles/2), Random.Range(-spreadAngles/2,spreadAngles/2), 0);
            Projectile newProjectile = Instantiate(projectilePrefab, muzzle.position, randomRotation);

            newProjectile.SetVelocity(projVelocity * Random.Range(1 - randomizeVelocityCoef, 1+randomizeVelocityCoef));
            newProjectile.SetLifeTime(lifeTime);
            newProjectile.Damage = damage;
            }
        
    }


}
