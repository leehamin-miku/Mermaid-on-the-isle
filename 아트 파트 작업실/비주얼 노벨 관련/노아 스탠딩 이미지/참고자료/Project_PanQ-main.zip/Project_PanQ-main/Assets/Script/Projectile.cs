using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Projectile : MonoBehaviour
{

    public LayerMask mask;
    private float velocity = 10;
    private float damage = 1;
    public float Damage
    {
        get
        {
            return damage;
        }
        set
        {
            if (value < 0)
                damage = 0;
            else
                damage = value;
        }
    }


    public void SetVelocity(float velocity)
    {
        this.velocity = velocity;
    }

    public void SetLifeTime(float lifeTime)
    {
        Destroy(gameObject, lifeTime);
    }

    // Update is called once per frame
    void Update()
    {
        float moveDistance = Time.deltaTime * velocity;
        CheckCollisions(moveDistance);
        transform.Translate(Vector3.forward * moveDistance);
    }

    bool CheckCollisions(float moveDistance)
    {
        Ray ray = new Ray(transform.position, transform.forward);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, moveDistance, mask, QueryTriggerInteraction.Collide))
        {
            OnHitObject(hit);
            return true;
        }

        return false;
    }

    void OnHitObject(RaycastHit hit)
    {
        Debug.Log($"{this.name} 발사체가 {hit.collider.gameObject.name} 와 충돌!");
        IDamageable damageableObject = hit.collider.GetComponent<IDamageable>();
        if (damageableObject != null)
        {
            damageableObject.TakeHit(Damage, hit);
        }

        Vector3 originalSize = transform.localScale;
        // Quaternion originalRotation = transform.rotation;
        transform.SetParent(hit.transform);
        // transform.localScale = originalSize;
        //transform.localScale = Vector3.Scale(transform.localScale,hit.transform.localScale);
        
        transform.localScale = Vector3.Scale(transform.localScale, Utilities.GetReciprocalVector(hit.transform.localScale));
       
        velocity = 0;
        //GameObject.Destroy(this);
    }
}
