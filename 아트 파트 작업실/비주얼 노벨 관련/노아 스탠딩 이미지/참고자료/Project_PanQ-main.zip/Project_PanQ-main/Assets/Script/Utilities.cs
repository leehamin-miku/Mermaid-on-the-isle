using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Utilities
{
    // Start is called before the first frame update
    void Start()
    {
        
    }






    static public Vector3 GetReciprocalVector(Vector3 vector, bool regardInfinityAsZero = false){

        float infinityOrZero = regardInfinityAsZero ? float.PositiveInfinity : 0;

        float x = vector.x != 0 ? 1 / vector.x : infinityOrZero;
        float y = vector.y != 0 ? 1 / vector.y : infinityOrZero;
        float z = vector.z != 0 ? 1 / vector.z : infinityOrZero;

        return new Vector3(x, y,z);
    }
}
